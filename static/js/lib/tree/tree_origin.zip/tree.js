﻿var TreeLayout = function (baseSvg, size) {
    var _this = this;
    this.treeHelper = new TreeHelper(this);
    this.treeCut = new TreeCut(this);
    this.root = null;
    this.selectArr = [];
    this.draggingNode = null;
    this.nodeWidth = 150;
    this.nodeHeight = 43;
    this.viewHeight = size.viewerWidth;
    this.viewWidth = size.viewerHeight;
    this.translateX = size.translateX;
    this.translateY = size.translateY;
    this.type = size.type;
    this.baseSvg = baseSvg;
    this.multiSelect = false;
    this.tree = d3.layout.tree()
            .nodeSize([this.nodeHeight / 2, this.nodeWidth * 2]);
    this.tree.sort(function (a, b) {
        if (a.isRest) {
            if (a.isTop) {
                return -1;
            } else {
                return 1;
            }
        } else if (b.isRest) {
            if (b.isTop) {
                return 1;
            } else {
                return -1;
            }
        }
        if (a.documentCnt == b.documentCnt) {
            return b.Id < a.Id ? -1 : 1;
        }
        return b.documentCnt < a.documentCnt ? -1 : 1;
        //return b.name.toLowerCase() < a.name.toLowerCase() ? 1 : -1;
    });
    this.tree.children(function (d) {
        var children = null;
        if (d.myChildren && d.myChildren.length > 0) {
            children = [].concat(d.myChildren);
            if (d.afterList.length > 0) {
                d.addBottomRestNode();
                children.push(d.bottomRest);
            }
            if (d.beforeList.length) {
                d.addTopRestNode();
                children.push(d.topRest);
            }
        }
        return children;
    });
    this.treeNodeDic = new Array();   
    this.id = 0;
    var dragListener = new this.treeHelper.DragListener();
    this.drawNode = new DrawNode(dragListener);
    this.drawLink = new DrawLink();

    this.onClickNode = null;

    this.layoutTreeByURL = function (url) {
        baseSvg.selectAll('g').remove();
        baseSvg.selectAll('path').remove();
        _this.selectArr = [];
        _this.id = 0;
        d3.json(url, function (error, data) {
            if (data != null) {
                //_this.treeHelper.convertTreeData(treeData);
                _this.root = new TreeNode();
                _this.id = _this.root.initialize(data);
                var root = _this.root;
                _this.initialNodeDic(root);
                _this.tree.nodes(root);
                root.x0 = 0;
                root.y0 = 0;
                _this.treeCut.treeCut(root);
                _this.update(root);
                // updateNodeInformation(root, _this.type);
            }
        });
    };
    this.layoutTree = function (data) {
        baseSvg.selectAll('g').remove();
        baseSvg.selectAll('path').remove();
        _this.selectArr = [];
        _this.id = 0;
        if (data != null) {
            _this.root = new TreeNode();
            _this.id = _this.root.initialize(data);
            var root = _this.root;
            _this.initialNodeDic(root);
            _this.tree.nodes(root);
            root.x0 = 0;
            root.y0 = 0;
            _this.treeCut.treeCut(root);
            _this.update(root);
        }
    };
    this.resize = function(size) {
        _this.viewHeight = size.viewerWidth;
        _this.viewWidth = size.viewerHeight;
        _this.translateX = size.translateX;
        _this.translateY = size.translateY;
        _this.baseSvg.attr("transform", "translate(" + _this.translateX + "," + _this.translateY + ")rotate(-90)");
        var root = _this.root;
        root.x0 = 0;
        root.y0 = 0;
        _this.treeCut.treeCut();
        _this.update();
        //updateNodeInformation(root, _this.type);
        _this.highlight([]);

    } 
    this.deleteNode = function () {
        var selectArr = _this.selectArr;
        var parent = selectArr[0].parent;
        if (parent) {
            parent.removeChild(selectArr);
            selectArr = [];
            _this.highlight(selectArr);
            _this.treeCut.treeCut(parent);
            parent.updateFeatureVector();
            _this.update(parent);
        }  
    }    

    this.showNode = function (d, noClick)
    {
        if (d) {
            _this.treeCut.treeCut(d);
            _this.selectArr = [d];
        } else {
            _this.selectArr = [];
        }
        _this.update();
        
        _this.highlight(_this.selectArr, noClick);
    }

    this.click = function (d) {
        if (d3.event.defaultPrevented) return; // click suppressed
        function selectNode() {
            if (d.isRest) {
                if (d.isTop) {
                    _this.treeCut.showBefore(d.parent);
                } else {
                    //if (!_this.treeCut.showMore(d.parent)) {
                        _this.treeCut.showAfter(d.parent);
                    //}
                }
                _this.update(d);
                //updateNodeInformation(d.parent, _this.type);
                return;
            }
            _this.showNode(d);
            //updateNodeInformation(d, _this.type);
            if (_this.onClickNode != null) {
                _this.onClickNode(d);
            }
        }
        function addNode() {
            if (d.isRest || d === _this.root) {
                return;
            }
            var selectArr = _this.selectArr;
            if (!selectArr) {
                selectArr = [];
            }
            var index = selectArr.indexOf(d);
            if (index > -1) {
                selectArr.splice(index, 1);
            } else {
                var parent = d.parent;
                while (parent) {
                    index = selectArr.indexOf(parent);
                    if (index > -1) {
                        return;
                    }
                    parent = parent.parent;
                }
                selectArr.push(d);
            }
            _this.highlight(selectArr);
        }
        if (_this.multiSelect) {
            addNode();
        } else {
            selectNode();
        } 
    }
    this.setMulti = function (v) {
        _this.multiSelect = v;
    }

    function appearAni(anidata) {
        var node = anidata[0];
        var link = anidata[1];
        var draggingNode = _this.draggingNode;
        var drawNode = _this.drawNode;
        var drawLink = _this.drawLink;
        var nodeUpdate = drawNode.updateNodes(node, draggingNode);

        drawNode.drawNodeLabel.updateLabels(nodeUpdate);
        drawNode.drawHighlightRect.updateHighlightRects(nodeUpdate);
        drawNode.drawPin.updatePins(nodeUpdate);
        drawNode.drawDepthNode.updateDepthNodes(nodeUpdate);
        drawNode.drawRestNode.updateRestNode(nodeUpdate);
        drawLink.updateLinks(link, draggingNode);   
    }

    function disappearAni(anidata) {
        var node = anidata[0];
        var link = anidata[1];
        var nodes = anidata[2];
        var drawNode = _this.drawNode;
        var drawLink = _this.drawLink;
        var exitNode = node.exit();
        if (_this.draggingNode) {
            for (var i = 0; i < exitNode[0].length; i++) {
                if (exitNode[0][i] && exitNode[0][i].id == "node" + _this.draggingNode.Id) {
                    exitNode[0].splice(exitNode[0].indexOf(exitNode[0][i]), 1);
                }
            }
        }     
        var nodeExit = exitNode.transition()
            .duration(duration)
            .attr("transform", function (d) {
                var parent = d.parent;
                while (nodes.indexOf(parent) < 0) {
                    parent = parent.parent;
                }
                return "translate(" + parent.y + "," + parent.x + ")";
            })
            .style("opacity", 0)
            .remove();
        drawLink.removeLinks(link, nodes);

    }

    this.update = function () {      
        var nodes = _this.tree.nodes(_this.root).reverse();
        var links = _this.tree.links(nodes);

        var node = baseSvg.selectAll("g.node")
            .data(nodes, function (d) {
                return d.id || (d.id = ++_this.id);
            });
        var drawNode = _this.drawNode;
        var drawLink = _this.drawLink;
        var nodeEnter = drawNode.createNodes(node);
        nodeEnter.on('click', _this.click);
        drawNode.drawConnectRect.creatRects(nodeEnter);
        drawNode.drawNodeLabel.creatLabels(nodeEnter);
        drawNode.drawHighlightRect.createHighlightRects(nodeEnter);
        drawNode.drawPin.createPins(nodeEnter, _this.treeCut);
        drawNode.drawDepthNode.createDepthNodes(nodeEnter);
        drawNode.drawRestNode.createRestNodes(nodeEnter);
        drawLink.showRestLinks(nodeEnter);
   
        var link = baseSvg.selectAll("path.link")
            .data(links, function (d) {
                return d.target.id;
            });

        drawLink.createLinks(link);
        
        var aniData = [node, link, nodes];
        appearAni(aniData);
        disappearAni(aniData);
        nodes.forEach(function (d) {
            if (_this.draggingNode && _this.draggingNode === d) {
                return;
            }
            d.x0 = d.x;
            d.y0 = d.y;
        });
        _this.treeHelper.centerTree();
    }

    this.save = function () {
        var source = _this.root;
        var newRoot = {
            "Id": source.Id,
            "Children": [],
            "Documents":source.documents
        };
        var result = new Array();
        var queue = new Array();
        var startPtr = 0;
        var endPtr = 0;
        result[endPtr] = newRoot;
        queue[endPtr++] = source;       
        while (startPtr < endPtr) {
            if (queue[startPtr].allChildren) { 
                for (var i = 0; i < queue[startPtr].allChildren.length; i++) {
                    var children = {
                        "Id": queue[startPtr].allChildren[i].Id,
                        "Children": [],
                        "Documents": queue[startPtr].allChildren[i].documents
                    }
                    result[startPtr].Children.push(children);
                    result[endPtr] = children;
                    queue[endPtr++] = queue[startPtr].allChildren[i];
                }
            }
            startPtr++;
        }
        return newRoot;
    }

    this.highLightNodes = function(source) {
        for (var i = 0; i < source.length; i++) {
            _this.baseSvg.selectAll("#node" + source[i].Id).selectAll("rect.nodeRect").attr("class", "nodeRect highlight");
            _this.baseSvg.selectAll("#node" + source[i].Id).selectAll("text.nodeText").style("fill", "#f57c00");
        }
    }

    this.highlight = function (source, noClick) {
        _this.baseSvg.selectAll("text.nodeText").style("fill", "rgb(85,85,85)");
        _this.baseSvg.selectAll(".link").attr("class", "link");
        _this.baseSvg.selectAll("rect.nodeRect").attr("class", "nodeRect");
        for (var i = 0; i < source.length; i++) {
            if (noClick) {
                _this.baseSvg.selectAll("#node" + source[i].Id).selectAll("rect.nodeRect").attr("class", "nodeRect show");
            } else {
                _this.baseSvg.selectAll("#node" + source[i].Id).selectAll("rect.nodeRect").attr("class", "nodeRect highlight");
                _this.baseSvg.selectAll("#node" + source[i].Id).selectAll("text.nodeText").style("fill", "#f57c00");
            }            
            var temp = source[i];
            while (temp.parent) {
                _this.baseSvg.selectAll("#link" + temp.Id)
                    .attr("class", "link highlight");
                _this.baseSvg.selectAll("#node" + temp.parent.Id)
                    .selectAll("rect.nodeRect")
                    .attr("class", "nodeRect show");
                temp = temp.parent;
            }
        }
    }
    this.initialNodeDic = function(root) {
        var queue = new Array();
        var startPtr = 0;
        var endPtr = 0;
        queue[endPtr++] = root;

        while (startPtr < endPtr) {
            var current = queue[startPtr];
            this.treeNodeDic[current.Id] = current;

            if (current.allChildren != null) {
                for (var i = 0; i < current.allChildren.length; i++) {
                    queue[endPtr++] = current.allChildren[i];
                }
            }
            startPtr++;
        }
    };

    var getClickedNode = function () {
        if (_this.selectArr.length == 1) {
            return _this.selectArr[0];
        } else {
            return false;
        }
    }

    this.addDocument = function(id) {
        var clickedNode = getClickedNode();
        if (clickedNode) {
            clickedNode.documents.push(id);
            return true;
        } else {
            return false;
        }
    }
    function contains(arr, node) {
        for (var i = 0; i < arr.length; i++) {
            if (node == arr[i])
                return true;
        }
        return false;
    }
    this.findSimilarNode = function (ids) {
        var queue = new Array();
        var startPtr = 0;
        var endPtr = 0;
        var maxNode = null;
        var maxFScore = 0;
        queue[endPtr++] = _this.root;
        while (startPtr < endPtr) {
            var current = queue[startPtr];

            var currentIds = current.getAllDescendantId();
            var precision = 0;
            var recall = 0;
            var fScore = 0;

            var count = 0;
            for (var i = 0; i < ids.length; i++) {
                if (contains(currentIds, ids[i])) {
                    count++;
                }
            }
            precision = ids.length ? count / ids.length : 0;
            recall = currentIds.length ? count / currentIds.length : 0;
            fScore = (precision + recall) ? (2 * precision * recall) / (precision + recall) : 0;
            if (fScore > maxFScore) {
                maxNode = current;
                maxFScore = fScore;
            }

            if (queue[startPtr].allChildren) {
                for (var i = 0; i < queue[startPtr].allChildren.length; i++) {
                    queue[endPtr++] = queue[startPtr].allChildren[i];
                }
            }
            startPtr++;
        }
        return maxNode;
    }
}

