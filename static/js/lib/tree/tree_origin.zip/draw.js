﻿var duration = 750;
var DrawNode = function (dragListener) {
    var _this = this;
    this.drawConnectRect = new DrawConnectRect(dragListener);
    this.drawNodeLabel = new DrawNodeLabel(dragListener);
    this.drawHighlightRect = new DrawHighlightRect();
    this.drawPin = new DrawPin();
    this.drawDepthNode = new DrawDepthNode();
    this.drawRestNode = new DrawRestNode(dragListener);

    this.createNodes = function(nodes) {
        return nodes.enter().append("g")
            .call(dragListener.dragListener)
            .attr("class", function (d) {
                if (d.isRest) {
                    return "node rest";
                }
                return "node";
            })
            .attr("id", function (d) {
                return "node" + d.Id;
            })
            .attr("transform", function (d) {
                if (!d.parent) {
                    return "translate(" + d.y0 + "," + d.x0 + ")";
                }
                var parent = d.parent;
                while (!d3.selectAll("#node" + parent.Id)[0].length) {
                    if (!parent.parent) {
                        return "translate(" + parent.y0 + "," + parent.x0 + ")";
                    }
                    parent = parent.parent;
                }
                return "translate(" + parent.y + "," + parent.x + ")";
            })
            .on('mousedown', dragListener.dragTimerStart)
            .on('mousemove', dragListener.dragTimerStop)
            .on('mouseup', dragListener.dragTimerStop);
    }
    this.updateNodes = function (nodes, draggingNode) {
        return nodes.transition()
            .duration(duration)
            .attr("transform", function (d) {
                if (draggingNode && draggingNode === d) {
                    return "translate(" + d.y0 + "," + d.x0 + ")";
                }
                return "translate(" + d.y + "," + d.x + ")";
            });
    }     
}
var DrawConnectRect = function(dragListener) {
    var _this = this;
    this.creatRects = function(nodes) {
        nodes.append("rect")
            .attr('class', 'ghostCircle')
            .attr("width", 120)
            .attr("height", 70)
            .attr("y", -35)
            .attr("opacity", 0)
            .style("fill", "red")
            .attr('pointer-events', 'mouseover')
            .on("mouseover", dragListener.overCircle)
            .on("mouseout", dragListener.outCircle);
    }
}
var DrawNodeLabel = function (dragListener) {
    var _this = this;
    this.creatLabels = function (nodes) {
        nodes.append("text")
            .attr('class', 'nodeText')
            .attr("x", -22)
            .attr("y", "-1.5em")
            .attr("transform", "rotate(-90)")
            .attr("text-anchor", "start")
            .style("fill", "rgb(85,85,85)")
            .style("fill-opacity", 0)
            .on("mouseover", dragListener.overLabel)
            .on("mouseout", dragListener.outLabel)
            .selectAll("tspan")
            .data(function (d) {
                if (d.isRest) {
                    return [];
                }
                return d.label;
            })
            .enter()
            .append("tspan")
            .attr("x", -22)
            .attr("dy", "2.6em")
            .text(function (d) {
                return d;
            });
    }
    this.updateLabels = function(nodes) {
        nodes.select("text.nodeText")
            .style("fill-opacity", 1);
    }
}
var DrawHighlightRect = function() {
    var _this = this;
    this.createHighlightRects = function(nodes) {
        nodes.append("rect")
            .attr("class", "nodeRect")
            .attr("rx", 10)
            .attr("ry", 10);
    }
    this.updateHighlightRects = function(nodes) {
        nodes.select("rect.nodeRect")
            .attr("x", function (d) {
                var text = $("#node" + d.Id + " .nodeText");
                return Number(text.attr("x")) + 22;
            })
            .attr("y", function (d) {
                var text = $("#node" + d.Id + " .nodeText");
                return -(text.height() / 2) - 18;
            })
            .attr("height", function (d) {
                var text = $("#node" + d.Id + " .nodeText");
                return text.width() + 10;
            })
            .attr("width", function (d) {
                var text = $("#node" + d.Id + " .nodeText");
                return text.height() + 3;
            });
    }
}
var DrawPin = function() {
    var _this = this;
    this.createPins = function(nodes, treeCut) {
        nodes.append("svg")
            .attr("class", "nodeSvg")
            .append("image")
            .attr("class", "svgIcon")
            .attr("xlink:href", "/static/img/office-push-pin.svg")
            .on("click", function (node) {
                if (d3.select("#node" + node.Id).select(".svgIcon")[0][0]) {
                    d3.select("#node" + node.Id).select(".svgIcon").attr("class", "svgIconShow");
                    treeCut.pin(node, true);
                } else if (d3.select("#node" + node.Id).select(".svgIconShow")[0][0]) {
                    d3.select("#node" + node.Id).select(".svgIconShow").attr("class", "svgIcon");
                    treeCut.pin(node, false);
                }
            })
            .on("mouseover", function (node) {
                d3.select("#node" + node.Id).select(".svgIcon").attr("xlink:href", "/static/img/office-push-pin-black.svg");
            })
            .on("mouseout", function (node) {
                d3.select("#node" + node.Id).select(".svgIcon").attr("xlink:href", "/static/img/office-push-pin.svg");
            });
    }
    this.updatePins = function(nodes) {
        nodes.select("svg.nodeSvg")
            .attr("x", function (d) {
                var text = $("#node" + d.Id + " .nodeText");
                return Number(text.attr("x")) + text.width();
            })
            .attr("y", function (d) {
                var text = $("#node" + d.Id + " .nodeText");
                return -(text.height() / 2) - 4;
            })
            .style("display", function (d) {
                return d.isRest ? "none" : "block";
            });
    }
}
var DrawDepthNode = function() {
    var _this = this;
    this.createDepthNodes = function(nodes) {
        nodes.append("path")
            .attr('class', 'nodeDepth')
            .style("opacity", 0);
    }
    this.updateDepthNodes = function(nodes) {
        nodes.select("path.nodeDepth")
            .attr("d", function (d) {
                var radiu = 5;
                var text = $("#node" + d.Id + " .nodeText");
                var startX = text.width() + Number(text.attr("x")) + 5;
                var len = (d.getDepth()) * radiu;
                var x1 = startX + len * 0.5, x2 = len + startX - len * 0.5, x3 = len + startX;
                return "M" + startX + " 0 C" + x1 + " 0 " + x2 + " -" + radiu + " " + x3 + " -" + radiu + " A" + radiu + " " + radiu + " 0 1 1 " + x3 + " " + radiu + " C" + x2 + " " + radiu + " " + x1 + " 0 " + startX + " 0 Z";
            })
            .style("opacity", function (d) {
                return (d.allChildren && d.allChildren.length > 0 && (!d.myChildren || d.myChildren.length === 0)) ? 1 : 0;
            });
    }
}
var DrawRestNode = function (dragListener) {
    var _this = this;
    this.createRestNodes = function(nodes) {
        /*nodes.filter(".rest").append("circle")
            .attr('class', 'nodeRest')
            .attr("cx", 13)
            .attr("r", function (d) {
                return 3 + Math.log10(d.restChildrenCnt) * 5;
            })
            .attr("fill", function (d) {
                var parent = d;
                while (parent.parent) {
                    parent = parent.parent;
                }
                var tmp = parseInt((1-(d.restDocumentCnt / parent.documentCnt)) * 170) + 85;
                return "rgb(" + tmp + "," + tmp + "," + tmp + ")";
            });*/
        /*nodes.filter(".rest").append("rect")
            .attr("class", "nodeRest")
            .attr("rx", 6)
            .attr("ry", 6)
            .attr("x", 13)
            .on("mouseover", dragListener.overLabel)
            .on("mouseout", dragListener.outLabel)
            .attr("y", function(d) {
                return -(8 + Math.log10(d.restChildrenCnt) * 5);
            })
            .attr("width", 12)
            .attr("height", function (d) {
                return 16 + Math.log10(d.restChildrenCnt) * 10;
            })
            .attr("fill", function (d) {
                var parent = d;
                while (parent.parent) {
                    parent = parent.parent;
                }
                var tmp = parseInt((1-(d.restDocumentCnt / parent.documentCnt)) * 150) + 75;
                return "rgb(" + tmp + "," + tmp + "," + tmp + ")";
            });*/
        nodes.filter(".rest").append("ellipse")
            .attr('class', 'nodeRest')
            .attr("cx", 13)
            .attr("rx", 6)
            .attr("ry", function(d) {
                return 0;
            });
    }
    this.updateRestNode = function(nodes) {
        nodes.select(".nodeRest")
            .attr("ry", function (d) {
                return 6 + Math.log10(d.restChildrenCnt) * 6;
            })
            .attr("fill", function (d) {
                var parent = d;
                while (parent.parent) {
                    parent = parent.parent;
                }
                var tmp = parseInt((1 - (d.restDocumentCnt / parent.documentCnt)) * 100) + 85;
                return "rgb(" + tmp + "," + tmp + "," + tmp + ")";
            });
    }
}

var DrawLink = function() {
    var _this = this;
    var diagonal = d3.svg.diagonal()
            .projection(function (d) {
                return [d.y, d.x];
            });
    this.createLinks = function (links) {
        links.enter().insert("path", "g")
            .attr("class", "link")
            .attr("id", function (d) {
                return "link" + d.target.Id;
            })
            .attr("d", function (d) {
                var parent = d.source;
                while (!d3.selectAll("#node" + parent.Id)[0].length) {
                    if (parent.parent) {
                        parent = parent.parent;
                    } else {
                        break;
                    }
                }
                var o = {
                    x: parent.x0,
                    y: parent.y0
                };
                return diagonal({
                    source: o,
                    target: o
                });
            });
    }
    this.updateLinks = function (links, draggingNode) {
        links.transition()
            .duration(duration)
            .attr("d", function (d) {
                if (draggingNode && draggingNode === d.target) {
                    return null;
                }
                var text = $("#node" + d.source.Id + " .nodeText");
                var o = {
                    x: d.source.x,
                    y: d.source.y + text.width() + Number(text.attr("x")) + 5//labelwidth
                };
                return diagonal({
                    source: o,
                    target: d.target
                });
            });
        d3.selectAll(".restlink.top")
            .transition()
            .duration(duration)
            .attr("d", function (d) {
                var text = $("#node" + d.parent.Id + " .nodeText");
                var t = {
                    x: 5,
                    y: 0
                };
                var s = {
                    x: d.parent.x - d.x,
                    y: d.parent.y + text.width() + Number(text.attr("x")) + 5 - d.y
                };
                return diagonal({
                    source: s,
                    target: t
                });
            });
        d3.selectAll(".restlink.bottom")
            .transition()
            .duration(duration)
            .attr("d", function (d) {
                var text = $("#node" + d.parent.Id + " .nodeText");
                var t = {
                    x: -5,
                    y: 0
                };
                var s = {
                    x: d.parent.x - d.x,
                    y: d.parent.y + text.width() + Number(text.attr("x")) + 5 - d.y
                };
                return diagonal({
                    source: s,
                    target: t
                });
            });
    }
    this.removeLinks = function(links,nodes) {
        links.exit().transition()
            .duration(duration)
            .attr("d", function (d) {
                var parent = d.source;
                while (nodes.indexOf(parent) < 0) {
                    parent = parent.parent;
                }
                var o = {
                    x: parent.x,
                    y: parent.y
                };
                return diagonal({
                    source: o,
                    target: o
                });
            })
            .remove();
    }

    this.showRestLinks = function(nodes) {
        nodes.filter(".rest").append("path")
            .attr("class", "restlink top")
            .attr("d", function (d) {
                var text = $("#node" + d.parent.Id + " .nodeText");
                var s = {
                    x: d.parent.x - d.x,
                    y: d.parent.y + text.width() + Number(text.attr("x")) + 5 - d.y
                };
                return diagonal({
                    source: s,
                    target: s
                });
            });
        nodes.filter(".rest").append("path")
            .attr("class", "restlink bottom")
            .attr("d", function (d) {
                var text = $("#node" + d.parent.Id + " .nodeText");
                var s = {
                    x: d.parent.x - d.x,
                    y: d.parent.y + text.width() + Number(text.attr("x")) + 5 - d.y
                };
                return diagonal({
                    source: s,
                    target: s
                });
            });
    }
}